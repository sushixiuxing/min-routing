#ifndef TCPHIGHSPEEDTEST_H
#define TCPHIGHSPEEDTEST_H


class TcpHighSpeedTest
{
public:
  TcpHighSpeedTest();
};

#endif // TCPHIGHSPEEDTEST_H
